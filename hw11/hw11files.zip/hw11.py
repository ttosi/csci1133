import os
def get_targets(path):
    for file in os.listdir(path): 
        if os.path.isfile(path+'/'+file):
            if file.endswith('.txt'):
                print(path+'/'+file)  #.txt file, print out the path
        else:
            get_targets(path+'/'+file)  #Go into a subdirectory
